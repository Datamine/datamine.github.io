## Travelmap

This is a command-line tool to create images of (global) networks. Documentation is available at http://www.johnloeber.com/docs/travelmap_documentation.html
