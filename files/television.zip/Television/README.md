## Television Episode Summary Dataset 1950-2014, with Analysis

See documentation at www.johnloeber.com/docs/television_scrape.html

Datasets current as of November 1, 2014
